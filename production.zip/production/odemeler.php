
<?php include "header.php";

$carisor=$db->prepare("SELECT * FROM cariler where cari_id=:id");
$carisor->execute(array(
  'id' => $_GET['cari_id']
  ));

$caricek=$carisor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Cari Ödeme Özeti</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Cari Ödeme Özeti <small> </small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      
                     <?php if ($caricek['cari_tip']==1) { ?>
                       <center><a href="hesapozeti.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-danger btn-sm">Hesap Özeti</button></a></center>
                  <?php  }elseif ($caricek['cari_tip']==2) { ?>
                      <center><a href="carialacak.php?cari_id=<?php echo $caricek['cari_id']; ?>&cari_tip=<?php echo $caricek['cari_tip']; ?>"><button class="btn btn-danger btn-sm">Cariyi Alacaklandır</button></a></center>
                 <?php   } ?>
                 <center><a href="odemeislemleri.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-danger btn-sm">Ödeme Yap</button></a></center>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Cari Tipi</th>
                          <th>Ad Soyad / Firma Ünvanı</th>
                          <th>Telefon</th>
                          <th>Email</th>
                          <th>Adres</th>
                          <th>Bakiye</th>
                          <th>Tarih(Şimdi)</th>
                        </tr>
                      </thead>


                      <tbody>
                        <tr>
                          <td><?php if ($caricek['cari_tip']==1) {
                            echo"Müşteri";
                          }else{
                            echo "Toptancı";
                          } ?></td>
                          <td><?php echo $caricek['cari_adsoyad'] ?></td>
                          <td><?php echo $caricek['cari_telefon'] ?></td>
                          <td><?php echo $caricek['cari_email'] ?></td>
                          <td><?php echo $caricek['cari_adres'] ?></td>
                          <td><?php echo $caricek['cari_bakiye'] ?> ₺</td>
                          <td><?php date_default_timezone_set('Europe/Istanbul');
                              echo date('d.m.Y H:i:s');
                           ?></td>
                        </tr>
                      </tbody>
                       <thead>
                         
                        <tr>
                          <th>Dekont No</th>
                          <th colspan="2">Açıklama</th>
                          <th>Alınan Ödeme</th>
                          <th>Yapılan Ödeme</th>
                          <th>Ödeme Tipi</th>
                          <th colspan="2">Ödeme Tarihi</th>
                          
                        </tr>
                      </thead>


                      <tbody>
                        <?php
                          $odemesor=$db->prepare("SELECT * FROM odemeler where cari_id=:id");
                          $odemesor->execute(array(
                          'id' => $_GET['cari_id']
                           ));
                         while($odemecek=$odemesor->fetch(PDO::FETCH_ASSOC)) { 
                          ?>
                        <tr>
                          <td><?php echo $odemecek['dekont_no'] ?></td>
                          <td colspan="2"><?php echo $odemecek['odeme_aciklama'] ?></td>
                          <td><?php echo $odemecek['alinan_odeme'] ?> ₺</td>
                          <td><?php echo $odemecek['yapilan_odeme'] ?> ₺</td>
                          <td><?php if ($odemecek['odeme_tip']==1) {
                            echo "Nakit";
                          }elseif ($odemecek['odeme_tip']==2) {
                           echo "Kredi Kartı";
                          }
                          elseif ($odemecek['odeme_tip']==3) {
                           echo "Hesap";
                          } elseif ($odemecek['odeme_tip']==4) {
                           echo "Çek";
                          } 

                        ?></td>
                          <td colspan="2"><?php echo date_format(date_create($odemecek['odeme_tarihi']), 'd-m-Y / H:i:s');  ?></td>

                         
                        </tr>
                      <?php $genel+=$odemecek['yapilan_odeme']; } ?>
                      <tr>
                        <td colspan="7" align="right"><b>Cari Toplam Alınan Ödeme Tutarı : <?php echo $genel ?> ₺</b></td>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>