
<?php include "header.php";
//Belirli veriyi seçme işlemi
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
$teklifsor=$db->prepare("SELECT * FROM teklifbilgi where kullanici_id=:kullanici_id  order by teklif_id DESC");
$teklifsor->execute(array('kullanici_id' => $kullanici_id));
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Teklifler</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
             <div class="x_panel">
                  <div class="x_title">
                    <h2>Teklifler <small><?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                     
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                     Hızlıca teklifleri görüntüleyin.
                    </p>
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Teklif No</th>
                          <th>Ad Soyad (Ünvan)</th>
                          <th>Cari Açıklama</th>
                          <th>Teklif Tutar</th>
                          <th>Teklif Tarihi</th>
                          <th>İncele</th>
                          <th>Sil</th>
                        </tr>
                      </thead>


                      <tbody>
                        <?php 

                while($teklifcek=$teklifsor->fetch(PDO::FETCH_ASSOC)) {
                $carisor=$db->prepare("SELECT * FROM cariler where cari_id=:id and kullanici_id=:kullanici_id");
$carisor->execute(array(
  'id' => $teklifcek['cari_id'],
  'kullanici_id' => $kullanici_id
  ));
$caricek=$carisor->fetch(PDO::FETCH_ASSOC);

                 ?>
                        <tr>
                          <td><?php echo $teklifcek['teklif_id'] ?></td>
                          <td><?php echo $caricek['cari_adsoyad'] ?></td>
                          <td><?php echo $teklifcek['cari_aciklama'] ?></td>
                          <td><?php echo $teklifcek['teklif_tutar'] ?></td>
                          <td><?php echo $teklifcek['teklif_tarih'] ?></td>
                          <td><center><a href="teklifozeti.php?teklif_id=<?php echo $teklifcek['teklif_id']; ?>"><button class="btn btn-primary btn-xs">İncele</button></a></center></td>
                          <td><center><a href="../netting/islem.php?teklif_id=<?php echo $teklifcek['teklif_id']; ?>&teklifsil2=ok"><button class="btn btn-danger btn-xs">Sil</button></a></center></td>
                        </tr>
                      <?php    } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>