
<?php include "header.php";
//Belirli veriyi seçme işlemi
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
$urunsor=$db->prepare("SELECT urun_id,urun_ad,urun_barkod,urun_satis,urun_birim,urun_stok FROM stokurunler where urun_stok!=0 and kullanici_id=:kullanici_id order by urun_id DESC");
$urunsor->execute(array(
  'kullanici_id' => $kullanici_id
  ));
?>
    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Hızlı Alan</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Hızlı İşlemler<small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="yenicari.php"><button class="btn btn-danger btn-sm">Yeni Cari</button></a></center>
                      <center><a href="yeniurun.php"><button class="btn btn-danger btn-sm">Yeni Ürün</button></a></center>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                   <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                      Hızlı fiyat sorgulama yapabilirsiniz.
                    </p>
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Barkod No</th>
                          <th>Ürün Adı</th>
                          <th>Satış Fiyatı</th>
                          <th>Birim</th>
                          <th>Stok Durumu</th>
                          <th>Miktar</th>
                          <th>Satış</th>
                          <th>İncele</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 

                while($uruncek=$urunsor->fetch(PDO::FETCH_ASSOC)) { ?>
                        <tr>
                          <td><?php echo $uruncek['urun_barkod'] ?></td>
                          <td><?php echo $uruncek['urun_ad'] ?></td>
                          <td><?php echo $uruncek['urun_satis'] ?>₺</td>
                          <td><?php echo $uruncek['urun_birim'] ?></td>
                          <td><?php echo $uruncek['urun_stok'] ?></td>
                          <td><form action="../netting/islem.php" method="POST">
                                    <input type="hidden" name="urun_id" value="<?php echo $uruncek['urun_id'] ?>">
                                    <input type="hidden" name="kullanici_id" value="<?php echo $kullanicicek['kullanici_id'] ?>">
                                    <input id="middle-name" class="form-control" type="number" name="urun_adet" style="width: 100px">
                          </td>
                          <td><button type="submit" name="sepeteekle" class="btn btn-danger">Ekle</button></form></td>
                          <td><center><a href="urunincele.php?urun_id=<?php echo $uruncek['urun_id']; ?>"><button class="btn btn-success btn-xs">İncele</button></a></center></td>
                        </tr>
                        <?php  }?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
<?php include "footer.php" ?>