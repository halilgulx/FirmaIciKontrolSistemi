
<?php include "header.php";
$slidersor=$db->prepare("SELECT * FROM slider order by slider_sira");
$slidersor->execute();
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Slider</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sliderler <small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="sliderekle.php"><button class="btn btn-danger btn-sm">Yeni Slider</button></a></center>
                      <li><a class="collapse-link" ><b class="fa fa-chevron-up"></b></a>
                      </li>
                      <li><a class="close-link" ><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                            <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                    </p>
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Slider No</th>
                          <th>Slider Resim</th>
                          <th>Slider Ad</th>
                          <th>Slider Sıra</th>
                          <th>Slider Link</th>
                          <th>Slider Durum</th>
                          <th>Slider Düzenle</th>
                          <th>Slider Sil</th>
                        </tr>
                      </thead>
                      <tbody>

                <?php 

                while($slidercek=$slidersor->fetch(PDO::FETCH_ASSOC)) { ?>
                        <tr>
                          <td><?php echo $slidercek['slider_id'] ?></td>
                          <td><img width="200" src="../../<?php echo $slidercek['slider_resimyol'] ?>"></td>
                          <td><?php echo $slidercek['slider_ad'] ?></td>
                          <td><?php echo $slidercek['slider_sira'] ?></td>
                          <td><?php echo $slidercek['slider_link'] ?></td>
                          <td><?php 

                  if ($slidercek['slider_durum']==1) {?>

                  <button class="btn btn-primary btn-xs">Aktif</button>
                  <?php } else {?>
                  <button class="btn btn-danger btn-xs">Pasif</button>
                   <?php } ?>
              </center></td>
              <td><center><a href="sliderduzenle.php?slider_id=<?php echo $slidercek['slider_id']; ?>"><button class="btn btn-success btn-xs">Düzenle</button></a></center></td>
                          <td><center><a href="../netting/islem.php?slider_id=<?php echo $slidercek['slider_id']; ?>&slidersil=ok"><button class="btn btn-danger btn-xs">Sil</button></a></center></td>
                        </tr>
                         <?php  }?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>