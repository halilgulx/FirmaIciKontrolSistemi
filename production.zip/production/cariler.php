
<?php include "header.php";
//Belirli veriyi seçme işlemi
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
$carisor=$db->prepare("SELECT * FROM cariler where cari_tip=:tip and kullanici_id=:kullanici_id  order by cari_id DESC");
$carisor->execute(array(
  'tip' => $_GET['cari_tip'],
  'kullanici_id' => $kullanici_id
  ));
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><?php if ($_GET['cari_tip']==1) {
                      echo "Müşteri Cari";
                    }elseif ($_GET['cari_tip']==2) {
                      echo "Toptancı Cari";
                    } ?></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
             <div class="x_panel">
                  <div class="x_title">
                    <h2><?php if ($_GET['cari_tip']==1) {
                      echo "Müşteri Cari";
                    }elseif ($_GET['cari_tip']==2) {
                      echo "Toptancı Cari";
                    } ?> <small><?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <?php if ($_GET['cari_tip']==2) { ?>
                      <center><a href="carialacak.php?cari_tip=2"><button class="btn btn-danger btn-sm">Cariyi Alacaklandır</button></a></center>
                   <?php }elseif($_GET['cari_tip']==1) { ?>
                      <center><a href="carialacak.php?cari_tip=1"><button class="btn btn-danger btn-sm">Cariyi Borçlandır</button></a></center>
                    <?php }?>

                    <?php if ($_GET['cari_tip']==2) { ?>
                      <center><a href="odemeislemleri.php?cari_tip=2"><button class="btn btn-danger btn-sm">Ödeme Yap</button></a></center>
                   <?php }elseif($_GET['cari_tip']==1) { ?>
                      <center><a href="odemeislemleri.php?cari_tip=1"><button class="btn btn-danger btn-sm">Ödeme Al</button></a></center>
                    <?php }?>

                      <center><a href="yenicari.php"><button class="btn btn-danger btn-sm">Yeni Cari</button></a></center>
                      
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                     Hızlıca cari hesaplarda gezinin.
                    </p>
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Cari Tipi</th>
                          <th>Ad Soyad (Ünvan)</th>
                          <th>Telefon</th>
                          <th>Bakiye</th>
                          <th>Hesap</th>
                          <th>Sil</th>
                        </tr>
                      </thead>


                      <tbody>
                        <?php 

                while($caricek=$carisor->fetch(PDO::FETCH_ASSOC)) { ?>
                        <tr>
                          <td><?php if ($caricek['cari_tip']==1) {
                            echo"Müşteri";
                          }else{
                            echo "Toptancı";
                          } ?></td>
                          <td><?php echo $caricek['cari_adsoyad'] ?></td>
                          <td><?php echo $caricek['cari_telefon'] ?></td>
                          <td><?php echo $caricek['cari_bakiye'] ?> ₺</td>
                          <td><?php if ($_GET['cari_tip']==1) { ?>
                      <center><a href="hesapozeti.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-primary btn-xs">Hesap</button></a></center>
                  <?php  }elseif ($_GET['cari_tip']==2) { ?>
                      <center><a href="odemeler.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-primary btn-xs">Hesap</button></a></center>
                 <?php   } ?></td>
                          <td><center><a href="../netting/islem.php?cari_id=<?php echo $caricek['cari_id']; ?>&carisil=ok&cari_tip=<?php echo $caricek['cari_tip']; ?>"><button class="btn btn-danger btn-xs">Sil</button></a></center></td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>