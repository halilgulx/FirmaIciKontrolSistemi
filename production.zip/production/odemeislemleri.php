
<?php include "header.php" ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ödeme İşlemleri</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ödeme İşlemleri</h2>
                    <ul class="nav navbar-right panel_toolbox">
                       <center><a href="yenicari.php"><button class="btn btn-danger btn-sm">Yeni Cari</button></a></center>
                       <li><a class="collapse-link" href="cariler.php?cari_tip=<?php echo $_GET['cari_tip']?>" title="Cariye Dön"><i class="fa fa-chevron-left" style="color: grey;"></i></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                       <div class="x_content">
                          <!-- start form for validation -->
                          <?php 
                        if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
                        if ($_GET['cari_tip']==2) { 
                          
    $carisor=$db->prepare("SELECT * FROM cariler where cari_tip=2 and kullanici_id=:kullanici_id order by cari_id DESC");
                          $carisor->execute(array(
                        'kullanici_id' => $kullanici_id
                         ));

 }elseif($_GET['cari_tip']==1) {  $carisor=$db->prepare("SELECT * FROM cariler where cari_tip=1 and kullanici_id=:kullanici_id order by cari_id DESC");
                          $carisor->execute(array(
                        'kullanici_id' => $kullanici_id
                         )); }?>
                <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ad Soyad <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                            <span class="fa fa-user form-control-feedback right"aria-hidden="true"></span> <select name="cari_id" id="heard" class="form-control" required>
                          <option value="0">Cari Seçiniz</option>
                         <?php while($caricek=$carisor->fetch(PDO::FETCH_ASSOC)) { 

                          if ($caricek['cari_id']==$_GET['cari_id']) { ?>
                            <option selected="" value="<?php echo $caricek['cari_id'] ?>"><?php echo $caricek['cari_adsoyad'] ?></option>
                       <?php   } else{ ?>
                          <option value="<?php echo $caricek['cari_id'] ?>"><?php echo $caricek['cari_adsoyad'] ?></option>
                        <?php } } ?>
                        </select>
                      </div>
                    </div>

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Dekont No<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" value="0"  name="dekont_no"class="form-control "><span class="fa fa-barcode form-control-feedback right" aria-hidden="true"></span>
                        <input type="hidden" value="<?php echo $kullanici_id ?>" name="kullanici_id">
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ödeme Tutarı<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" value=".00"  name="yapilan_odeme"class="form-control "><span class="fa fa-try form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ödeme Tipi <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select id="heard" name="odeme_tip" class="form-control" required>
                          <option value="0">Ödeme Tipi Seçiniz</option>
                          <option value="1">Nakit</option>
                          <option value="2">Kredi Kartı</option>
                          <option value="3">Hesap</option>
                          <option value="4">Çek</option>
                        </select>
                        <span class="fa fa-edit form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                   <div class="item form-group">
                      <label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Ödeme Açıklama</label>
                      <div class="col-md-6 col-sm-6 ">
                      <textarea class="resizable_textarea form-control" name="odeme_aciklama" placeholder="Ödeme Açıklaması Girilebilir"></textarea>
                      <input type="hidden" value="<?php if($_GET['cari_tip']==1) { echo 2; }elseif($_GET['cari_tip']==2) { echo 1;} ?>" name="borclandir_alacak">
                      </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button class="btn btn-danger" type="reset">Temizle</button>
                        <button type="submit" name="odemekaydet" class="btn btn-primary">Ödemeyi Kaydet</button>
                      </div>
                    </div>

                  </form>
                  <!-- end form for validations -->
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>