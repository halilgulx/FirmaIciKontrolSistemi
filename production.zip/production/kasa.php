<?php include "header.php";
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}               
                 $genel=0;
                 $genelx=0;
                 $gunlukkar=0;
                 
                 $satilanurun=0;
                 $kasa_detaysor=$db->prepare("SELECT * FROM kasa_detay where kasa_id=:kullanici_id order by kadetay_id DESC");
                 $kasa_detaysor->execute(array('kullanici_id'=>$kullanici_id));
                 
                 while ($kasa_detaycek=$kasa_detaysor->fetch(PDO::FETCH_ASSOC)) {
                  if (date_format(date_create($kasa_detaycek['kadetay_tarihbas']), 'd-m-Y')==date('d-m-Y')) {
                    $kasadurum=$kasa_detaycek['kadetay_baskasa'];
                  }
                 }
                
                 $siparissor=$db->prepare("SELECT * FROM siparisler where kullanici_id=:kullanici_id order by urun_id DESC");
                 $siparissor->execute(array('kullanici_id'=>$kullanici_id));
                        
                while($sipariscek=$siparissor->fetch(PDO::FETCH_ASSOC)) {
                 $urun_id=$sipariscek['urun_id'];
                 $urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:urun_id and kullanici_id=:kullanici_id");
                 $urunsor->execute(array(
                   'urun_id' => $urun_id,
                   'kullanici_id' => $kullanici_id
                ));
              if (date_format(date_create($sipariscek['siparis_tarih']), 'd-m-Y')==date('d-m-Y')) {
           $uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
          $satir=$sipariscek['urun_adet']*$uruncek['urun_satis'];
          $gunluksatis=$gunluksatis+$satir;
          $kasadurum=$kasadurum+$satir;
          $satilanurun+=$sipariscek['urun_adet'];
          $urunkar=$uruncek['urun_satis']-$uruncek['urun_alis'];
          $gunlukkar+=$urunkar*$sipariscek['urun_adet'];
              }
         
                          }
                           
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Kasa</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kasa <small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="kasaislemleri.php?tip=1"><button class="btn btn-danger btn-sm">Yeni Günü Başlat</button></a></center>
                      <center><a href="kasaislemleri.php?tip=2"><button class="btn btn-danger btn-sm">Günü Kapat</button></a></center>
                      <center><a href="kasaislemleri.php?tip=3"><button class="btn btn-danger btn-sm">Gider Ekle</button></a></center>
                      <li><a class="collapse-link" ><b class="fa fa-chevron-up"></b></a>
                      </li>
                      <li><a class="close-link" ><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <div class="row">
                    
                    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $kasadurum ?> ₺</div>

                          <h3>Güncel Kasa Tutarı</h3>
                          <p>Kasanın güncel bakiyesi.</p>
                        </div>
                      </div>

                       <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-cube"></i>
                          </div>
                          <div class="count"><?php echo $satilanurun ?></div>

                          <h3>adet satıldı</h3>
                          <p>Mağazanın günlük satış adeti.</p>
                        </div>
                      </div>

                      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $gunluksatis ?> ₺</div>

                          <h3>Günlük Satış Tutarı </h3>
                          <p>Mağaza günlük satış tutarı.</p>
                        </div>
                      </div>

                       <?php if ($kullanicicek['kullanici_yetki']==2) { ?>
                        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $gunlukkar ?></div>

                          <h3>Günlük Kar :</h3>
                          <p>Mağazanın Günlük Karı.</p>
                        </div>
                      </div>
                   <?php  } ?>
<hr width="100%" size="6">
                       <h4>Günlük Yapılan Satışlar</h4>

                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                    </p>
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Sipariş No</th>
                          <th>Ürün Adı</th>
                          <th>Miktar</th>
                          <th>Birim Fiyat</th>
                          <th>Satır Toplam</th>
                          <th>Alınan Tarih</th>
                        </tr>
                      </thead>


                      <tbody>

  <?php
       $siparissor=$db->prepare("SELECT * FROM siparisler where kullanici_id=:kullanici_id order by urun_id DESC");
       $siparissor->execute(array(
        'kullanici_id'=>$kullanici_id
       ));
       while($sipariscek=$siparissor->fetch(PDO::FETCH_ASSOC)) {
        $urun_id=$sipariscek['urun_id'];
        $urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:urun_id and kullanici_id=:kullanici_id");
        $urunsor->execute(array(
          'urun_id' => $urun_id,
          'kullanici_id' => $kullanici_id
       ));
       if (date_format(date_create($sipariscek['siparis_tarih']), 'd-m-Y')==date('d-m-Y')) {
        $uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
  ?>
                  <tr>
                    <td><?php echo $sipariscek['siparis_no'] ?></td>
                    <td><?php echo $uruncek['urun_ad'] ?></td>
                    <td><?php echo $sipariscek['urun_adet'] ?></td>
                    <td><?php echo $sipariscek['urun_satis'] ?></td>
                    <td><?php echo $satirtop=$sipariscek['urun_adet']*$sipariscek['urun_satis'] ?> ₺</td>
                    <td><?php echo date_format(date_create($sipariscek['siparis_tarih']), 'd-m-Y / H:i:s'); ?></td>
                  </tr>
                     <?php $genel+=$satirtop; } }?>
                      </tbody>
                    </table>
                    <b>Cari Toplam Sipariş Tutarı : <?php echo $genel ?> ₺</b>
                  </div>
                </div>
                
                <hr width="100%" size="6">
                
                <h4>Günlük Yapılan Ödemeler</h4>

                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                     
                    </p>
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Dekont No</th>
                          <th>Cari Ad Soyad</th>
                          <th>Ödeme Tipi</th>
                          <th>Yapılan Ödeme</th>
                          <th>Ödeme Açıklama</th>
                          <th>Ödeme Tarihi</th>
                        </tr>
                      </thead>


                      <tbody>

    <?php
        
        $odemesor=$db->prepare("SELECT * FROM odemeler where kullanici_id=:kullanici_id and borclandir_alacak=1 order by odemeler_id DESC");
        $odemesor->execute(array(
          'kullanici_id'=>$kullanici_id
        ));
        while($odemecek=$odemesor->fetch(PDO::FETCH_ASSOC)) {
          $cari_id=$odemecek['cari_id'];
          $carisor=$db->prepare("SELECT * FROM cariler where cari_id=:cari_id and kullanici_id=:kullanici_id");
          $carisor->execute(array(
            'cari_id' => $cari_id,
            'kullanici_id' => $kullanici_id
          ));
        if (date_format(date_create($odemecek['odeme_tarihi']), 'd-m-Y')==date('d-m-Y') && $odemecek['yapilan_odeme']!=0) {
           $caricek=$carisor->fetch(PDO::FETCH_ASSOC);
    ?>
                  <tr>
                    <td><?php echo $odemecek['dekont_no'] ?></td>
                    <td><?php if($odemecek['cari_id']==0){ echo $odemecek['cari_adsoyad']; }else{echo $caricek['cari_adsoyad'];} ?></td>

                    <td><?php if ($odemecek['odeme_tip']==1) {
                            echo "Yakıt";
                          }elseif ($odemecek['odeme_tip']==2) {
                            echo "Market";
                          }elseif ($odemecek['odeme_tip']==3) {
                            echo "Bireysel";
                          }elseif ($odemecek['odeme_tip']==4) {
                            echo "Maaş";
                          }elseif ($odemecek['odeme_tip']==5) {
                            echo "Diğer";
                          } ?></td>
                    <td><?php echo $odemecek['yapilan_odeme'] ?> ₺</td>
                    <td><?php echo $odemecek['odeme_aciklama'] ?></td>
                    <td><?php echo date_format(date_create($odemecek['odeme_tarihi']), 'd-m-Y / H:i:s'); ?></td>
                  </tr>
                   <?php $genelx+=$odemecek['yapilan_odeme']; }}?>
                  </tbody>
                 </table>
                 <b>Günlük Yapılan Ödeme Tutarı : <?php echo $genelx ?> ₺</b>
                  </div>
                </div>
                <hr width="100%" size="6">
 

<?php if ($kullanicicek['kullanici_yetki']==2) { ?>
                     <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $gunlukkar ?></div>

                          <h3>Günlük Kar :</h3>
                          <p>Mağazanın Günlük Karı.</p>
                        </div>
                      </div>
                       <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $genelx ?></div>

                          <h3>Günlük Gider :</h3>
                          <p>Mağazanın Günlük Gideri.</p>
                        </div>
                      </div>
                       <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $netkar=$gunlukkar-$genelx ?></div>

                          <h3>Günlük Net Kar :</h3>
                          <p>Mağazanın Günlük Net Karı.</p>
                        </div>
                      </div>
                    <?php } ?>

                 
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>