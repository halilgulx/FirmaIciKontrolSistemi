
<?php include "header.php";
$projesor=$db->prepare("SELECT * FROM projeler order by proje_id");
$projesor->execute();
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Projeler</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Projeler <small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="projeekle.php"><button class="btn btn-danger btn-sm">Yeni Proje</button></a></center>
                      <li><a class="collapse-link" ><b class="fa fa-chevron-up"></b></a>
                      </li>
                      <li><a class="close-link" ><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                            <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                    </p>
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Proje No</th>
                          <th>Proje Resim</th>
                          <th>proje Ad</th>
                          <th>Proje Grup</th>
                          <th>Proje Link</th>
                          <th>Proje Durum</th>
                          <th>Proje Düzenle</th>
                          <th>Proje Sil</th>
                        </tr>
                      </thead>
                      <tbody>

                <?php 

                while($projecek=$projesor->fetch(PDO::FETCH_ASSOC)) { ?>
                        <tr>
                          <td><?php echo $projecek['proje_id'] ?></td>
                          <td><img width="200" src="../../<?php echo $projecek['proje_resimyol'] ?>"></td>
                          <td><?php echo $projecek['proje_ad'] ?></td>
                           <td><?php 

                  if ($projecek['proje_grup']==0) {?>

                  E-Ticaret
                  <?php } elseif ($projecek['proje_grup']==1) {?>
                    Ön Muhasebe
                <?php } elseif ($projecek['proje_grup']==2) {?>
                  Grafik
                <?php } elseif ($projecek['proje_grup']==3) {?>
                  Web Tasarım
                   <?php } ?>
              </center></td>
                          <td><?php echo $projecek['proje_link'] ?></td>
                          <td><?php 

                  if ($projecek['proje_durum']==1) {?>

                  <button class="btn btn-primary btn-xs">Aktif</button>
                  <?php } else {?>
                  <button class="btn btn-danger btn-xs">Pasif</button>
                   <?php } ?>
              </center></td>
              <td><center><a href="projeduzenle.php?proje_id=<?php echo $projecek['proje_id']; ?>"><button class="btn btn-success btn-xs">Düzenle</button></a></center></td>
                          <td><center><a href="../netting/islem.php?proje_id=<?php echo $projecek['proje_id']; ?>&projesil=ok"><button class="btn btn-danger btn-xs">Sil</button></a></center></td>
                        </tr>
                         <?php  }?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>