
<?php include "header.php";

$carisor=$db->prepare("SELECT * FROM cariler where cari_id=:id");
$carisor->execute(array(
  'id' => $_GET['cari_id']
  ));

$caricek=$carisor->fetch(PDO::FETCH_ASSOC);
?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Hesap Ayarları</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Hesap Ayarları <small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="hesapozeti.php?cari_id=<?php echo $caricek['cari_id']?>"><button class="btn btn-danger btn-sm">Hesap Özeti</button></a></center>
                      <li><a class="collapse-link" ><b class="fa fa-chevron-up"></b></a>
                      </li>
                      <li><a class="close-link" ><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                   <br />
                  <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ad Soyad<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="cari_adsoyad" value="<?php echo $caricek['cari_adsoyad']?>" disabled="disabled" required="required" class="form-control ">
                        <input type="hidden" value="<?php echo $caricek['cari_id']?>" name="cari_id">
                        <span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Telefon<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="cari_telefon" value="<?php echo $caricek['cari_telefon']?>" required="required" class="form-control ">
                        <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Mail<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="cari_email" value="<?php echo $caricek['cari_email']?>" required="required" class="form-control ">
                        <span class="fa fa-envelope form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Adres<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                         <input type="text" id="first-name" name="cari_adres" value="<?php echo $caricek['cari_adres']?>" required="required" class="form-control ">
                        <span class="fa fa-map-marker form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Cari Durum <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                            <span class="fa fa-user form-control-feedback right"aria-hidden="true"></span> <select name="cari_durum" id="heard" class="form-control" required>
                         <?php 
                          if ($caricek['cari_durum']=='1') { ?>
                            <option selected="selected" value="<?php echo $caricek['cari_durum'] ?>">Aktif</option>
                            <option  value="2">Pasif</option>
                         <?php }elseif ($caricek['cari_durum']=='2') {?>
                          <option value="1">Aktif</option>
                           <option selected="selected" value="<?php echo $caricek['cari_durum'] ?>">Pasif</option>
                        <?php }
                          ?>
                          
                        </select>
                      </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <button type="submit" name="cari_guncelle" class="btn btn-primary">Güncelle</button>
                      </div>
                    </div>

                  </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>