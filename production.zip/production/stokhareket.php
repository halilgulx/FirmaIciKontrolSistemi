
<?php 
include "header.php";
//Belirli veriyi seçme işlemi
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
$xurunsor=$db->prepare("SELECT * FROM stokurunler where kullanici_id=:kullanici_id order by urun_id DESC");
$xurunsor->execute(array('kullanici_id'=>$kullanici_id));
while($xuruncek=$xurunsor->fetch(PDO::FETCH_ASSOC)) {
                  $xsiparissor=$db->prepare("SELECT * FROM siparisler where kullanici_id=:kullanici_id order by urun_id DESC");
                  $xsiparissor->execute(array('kullanici_id'=>$kullanici_id));
                  $topurun=0;
                  while($xsipariscek=$xsiparissor->fetch(PDO::FETCH_ASSOC)) {
                    if ($xuruncek['urun_id']==$xsipariscek['urun_id']) {
                      $topurun+=$xsipariscek['urun_adet'];
                       $xgenelfiyat+= $xsipariscek['urun_adet']*$xuruncek['urun_satis'];
                    }
                    
                  }
                 
                  $topsat+=$topurun;
                  $guncelstok1+=$xuruncek['urun_stok'];
                } 
 ?>
    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Stok Hareketleri  </h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Stok Hareketleri <small><?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                     
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close" title="Kapat"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                   <div class="x_content">
                   
                      <div class="row">
                         <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-cube"></i>
                          </div>
                          <div class="count"><?php echo $guncelstok1 ?></div>

                          <h3>Toplam Ürün Sayısı</h3>
                          <p>Mağaza da bulunan toplam ürün sayısı.</p>
                        </div>
                      </div>
                        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-shopping-cart"></i>
                          </div>
                          <div class="count"><?php echo $topsat ?></div>

                          <h3>Satılan Ürün Sayısı</h3>
                          <p>Mağaza da satılan toplam ürün sayısı.</p>
                        </div>
                      </div>
                       <div class="animated flipInY col-lg-3 col-md-3 col-sm-6  ">
                        <div class="tile-stats">
                          <div class="icon"><i class="fa fa-try"></i>
                          </div>
                          <div class="count"><?php echo $xgenelfiyat ?></div>

                          <h3>Satış Toplam Tutarı</h3>
                          <p>Satılan ürünün toplam tutarı.</p>
                        </div>
                      </div>
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                    </p>
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Barkod No</th>
                          <th>Stok Kodu</th>
                          <th>Ürün Adı</th>
                          <th>Alış Fiyatı</th>
                          <th>Satış Fiyatı</th>
                          <th>Kdv</th>
                          <th>Birim</th>
                          <th>Stok Durumu</th>
                          <th>Toplam Satış Adeti</th>
                        </tr>
                      </thead>
                      <tbody>

                <?php 
                $urunsor=$db->prepare("SELECT * FROM stokurunler where kullanici_id=:kullanici_id order by urun_id DESC");
                $urunsor->execute(array('kullanici_id'=>$kullanici_id));
                while($uruncek=$urunsor->fetch(PDO::FETCH_ASSOC)) {
                  $siparissor=$db->prepare("SELECT * FROM siparisler where kullanici_id=:kullanici_id order by urun_id DESC");
                  $siparissor->execute(array('kullanici_id'=>$kullanici_id));
                  $topurun=0;
                  while($sipariscek=$siparissor->fetch(PDO::FETCH_ASSOC)) {
                    if ($uruncek['urun_id']==$sipariscek['urun_id']) {
                      $topurun+=$sipariscek['urun_adet'];
                    }
                  }


                 ?>
                        <tr>
                          <td><?php echo $uruncek['urun_barkod'] ?></td>
                          <td><?php echo $uruncek['urun_stokkod'] ?></td>
                          <td><?php echo $uruncek['urun_ad'] ?></td>
                          <td><?php echo $uruncek['urun_alis'] ?>₺</td>
                          <td><?php echo $uruncek['urun_satis'] ?>₺</td>
                          <td>%<?php echo $uruncek['urun_kdv'] ?></td>
                          <td><?php echo $uruncek['urun_birim'] ?></td>
                          <td><?php echo $uruncek['urun_stok'] ?></td>
                          <td><?php echo $topurun ?> Adet</td>
                          
                        </tr>
                         <?php $genel+=$topurun; $guncelstok=+$uruncek['urun_stok']; }?>
                      </tbody>
                    </table>
                    
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>
            </div>
          </div>
          <div style="text-align: right; padding-right: 100px; font-size: 25px;"><b>Toplam Ürün Satışı : <?php $guncelstok1==$guncelstok;  echo $genel; ?> Adet</b></div>
        </div>
        <!-- /page content -->
<?php include "footer.php" ?>