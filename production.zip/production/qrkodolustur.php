
<?php include "header.php";
	

$urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:id");
$urunsor->execute(array(
  'id' => $_GET['urun_id']
  ));

$uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Qr Kod Oluştur</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Qr Kod Oluştur</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link" href="urunstok.php" title="Ürünler Sayfasına Dön"><i class="fa fa-chevron-left" style="color: grey;"></i></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content"><br />
									<form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">

										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Barkod No <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input type="text" id="first-name" name="urun_barkod" value="<?php echo $uruncek['urun_barkod'] ?>" required="required" class="form-control " disabled>
												<span class="fa fa-barcode form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
									
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Ürün Adı</label>
											<div class="col-md-6 col-sm-6 ">
												<input id="middle-name" class="form-control" value="<?php echo $uruncek['urun_ad'] ?>" type="text" name="urun_ad" disabled>
												<span class="fa fa-pencil form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Qr Kod</label>
											<div class="col-md-6 col-sm-6 ">
												<a href="images/qrkod.png">  <?php 

                      $urunid=$_GET['urun_id'];
                      require "../netting/barkodqr.php";
                      $qrCode = new BarcodeQr();
                      $qrCode ->url("xadmin/production/urunincele.php?urun_id=$urunid");
                      $qrCode->draw(200,"images/qrkod.png");
                      echo '<img src="images/qrkod.png">';
                      
                   ?></a> 
											</div>
										</div>
										<div class="ln_solid"></div>
									</form>
									<a href="index.php"><button class="btn btn-primary">Hızlı İşlemlere Git</button></a>
									<a href="urunstok.php"><button class="btn btn-primary">Stok Ürünlere Git</button></a>
									<a href="images/qrkod.png" download="qrkod.png"><button class="btn btn-primary">Qr Kodu İndir</button></a>
								</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>