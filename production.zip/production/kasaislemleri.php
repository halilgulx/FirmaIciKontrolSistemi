
<?php include "header.php";
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}

 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3><?php if ($_GET['tip']==1) {
                  echo "Yeni Günü Başlat";
                }elseif($_GET['tip']==2){echo "Günü Bitir";}elseif($_GET['tip']==3){echo "Gider Ekle";} ?></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2><?php if ($_GET['tip']==1) {
                  echo "Yeni Günü Başlat";
                }elseif($_GET['tip']==2){echo "Günü Bitir";}elseif($_GET['tip']==3){echo "Gider Ekle";} ?> <small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link" ><b class="fa fa-chevron-up"></b></a>
                      </li>
                      <li><a class="close-link" ><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <?php if ($_GET['tip']==1) {?>
                   <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Kasa Başlangıç Bakiyesi<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" value=".00"  name="kadetay_baskasa"class="form-control "><span class="fa fa-try form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <input type="hidden" name="kullanici_id" value="<?php echo $kullanici_id ?>">
                        <button class="btn btn-danger" type="reset">Temizle</button>
                        <button type="submit" name="gunubaslat" class="btn btn-primary">Günü Başlat</button>
                      </div>
                    </div>

                  </form>

              <?php  } elseif ($_GET['tip']==2) { ?>
                   <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Kasa Bitiş Bakiyesi<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" value=".00"  name="kadetay_kasabit"class="form-control "><span class="fa fa-try form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Kasa Durum Açıklama</label>
                      <div class="col-md-6 col-sm-6 ">
                      <textarea class="resizable_textarea form-control" name="kadetay_aciklama" placeholder="Örnek 1500tl nakit 100tl kredi kartı vs. "></textarea>
                      </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <input type="hidden" name="kullanici_id" value="<?php echo $kullanici_id ?>">
                        <button class="btn btn-danger" type="reset">Temizle</button>
                        <button type="submit" name="gunubitir" class="btn btn-primary">Günü Bitir</button>
                        <input type="hidden" name="kadetay_id" value="2">
                      </div>
                    </div>

                  </form>


                <?php }elseif ($_GET['tip']==3) { ?>
                   <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ad Soyad<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" value="Çalışan"  name="gcari_adsoyad"class="form-control "><span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div> 
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Gider Tipi<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <select name="gider_tip" class="form-control ">
                         <option value="0">Gider Tipi Seçiniz</option>
                         <option value="1">Yakıt</option>
                         <option value="2">Market</option>
                         <option value="3">Bireysel</option>
                         <option value="4">Maaş</option>
                         <option value="5">Diğer</option>
                       </select>
                       <span class="fa fa-down form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ödeme Tipi <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <select id="heard" name="odeme_tip" class="form-control" required>
                          <option value="0">Ödeme Tipi Seçiniz</option>
                          <option value="1">Nakit</option>
                          <option value="2">Kredi Kartı</option>
                          <option value="3">Hesap</option>
                          <option value="4">Çek</option>
                        </select>
                        <span class="fa fa-edit form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Gider Tutarı<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" value=".00"  name="yapilan_odeme"class="form-control "><span class="fa fa-try form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Gider Açıklama</label>
                      <div class="col-md-6 col-sm-6 ">
                      <textarea class="resizable_textarea form-control" name="gider_aciklama" placeholder="Örnek: plakalı Araca 100 tl yakıt / Marketten bardak, su aldım.  vs. "></textarea>
                      </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <input type="hidden" name="kullanici_id" value="<?php echo $kullanici_id ?>">
                        <input type="hidden" name="borclandir_alacak" value="1">
                        <button class="btn btn-danger" type="reset">Temizle</button>
                        <button type="submit" name="giderekle" class="btn btn-primary">Gideri Ekle</button>
                      </div>
                    </div>
        
                  </form>
                <?php } ?> 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>