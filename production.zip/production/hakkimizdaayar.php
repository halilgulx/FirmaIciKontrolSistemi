
<?php include "header.php";
$hakkimizdasor=$db->prepare("SELECT * FROM hakkimizda where hakkimizda_id=:id");
$hakkimizdasor->execute(array(
  'id' => 1
  ));
$hakkimizdacek=$hakkimizdasor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ayarlar</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Hakkımızda Ayar <small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link" ><b class="fa fa-chevron-up"></b></a>
                      </li>
                      <li><a class="close-link" ><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                 <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">

                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Hakkımızda Başlık<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_baslik" value="<?php echo $hakkimizdacek['hakkimizda_baslik'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                  
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Hakkımızda İçerik <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="hakkimizda_icerik" value="<?php echo $hakkimizdacek['hakkimizda_icerik'] ?>" placeholder="<?php echo $hakkimizdacek['hakkimizda_icerik'] ?>"></textarea>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Hakkımızda Video Link<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_video" value="<?php echo $hakkimizdacek['hakkimizda_video'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Alt Başlık 1<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_baslikone" value="<?php echo $hakkimizdacek['hakkimizda_baslikone'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                  
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alt İçerik 1<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="hakkimizda_icerikone" value="<?php echo $hakkimizdacek['hakkimizda_icerikone'] ?>" placeholder="<?php echo $hakkimizdacek['hakkimizda_icerikone'] ?>"></textarea>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Alt Başlık 2<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_basliktwo" value="<?php echo $hakkimizdacek['hakkimizda_basliktwo'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                  
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alt İçerik 2<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="hakkimizda_iceriktwo" value="<?php echo $hakkimizdacek['hakkimizda_iceriktwo'] ?>" placeholder="<?php echo $hakkimizdacek['hakkimizda_iceriktwo'] ?>"></textarea>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Alt Başlık 3<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_baslikthree" value="<?php echo $hakkimizdacek['hakkimizda_baslikthree'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                  
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alt İçerik 3<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="hakkimizda_icerikthree" value="<?php echo $hakkimizdacek['hakkimizda_icerikthree'] ?>" placeholder="<?php echo $hakkimizdacek['hakkimizda_icerikthree'] ?>"></textarea>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Alt Başlık 4<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_baslikfour" value="<?php echo $hakkimizdacek['hakkimizda_baslikfour'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                  
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alt İçerik 4<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="hakkimizda_icerikfour" value="<?php echo $hakkimizdacek['hakkimizda_icerikfour'] ?>" placeholder="<?php echo $hakkimizdacek['hakkimizda_icerikfour'] ?>"></textarea>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Alt Başlık 5<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" name="hakkimizda_baslikfive" value="<?php echo $hakkimizdacek['hakkimizda_baslikfive'] ?>" required="required" class="form-control ">
                      </div>
                    </div>
                  
                   <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Alt İçerik 5<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="hakkimizda_icerikfive" value="<?php echo $hakkimizdacek['hakkimizda_icerikfive'] ?>" placeholder="<?php echo $hakkimizdacek['hakkimizda_icerikfive'] ?>"></textarea>
                      </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                                              <button type="submit" name="hakkimizdaayar" class="btn btn-primary">Güncelle</button>
                      </div>
                    </div>

                  </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>