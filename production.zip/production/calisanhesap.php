
<?php include "header.php";

$kullanicisor=$db->prepare("SELECT * FROM kullanici where kullanici_id=:id");
$kullanicisor->execute(array(
  'id' => $_GET['kullanici_id']
  ));

$kullanicicek=$kullanicisor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Çalışan Hesap Bilgileri</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Çalışan Hesap Bilgileri <small> </small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="kullanicilar.php"><button class="btn btn-danger btn-sm">Kullanıcılar</button></a></center>
                      <center><a href="ayarlar.php?kullanici_id=<?php echo $kullanicicek['kullanici_id']; ?>"><button class="btn btn-danger btn-sm">Bilgileri Güncelle</button></a></center>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Kullanıcı Adı</th>
                          <th>Ad Soyad / Ünvanı</th>
                          <th>Telefon</th>
                          <th>Email</th>
                          <th>Adres</th>
                          <th>Durum</th>
                        </tr>
                      </thead>


                      <tbody>
                        <tr>
                          <td><?php echo $kullanicicek['kullanici_kadi'] ?></td>
                          <td><?php echo $kullanicicek['kullanici_ad'] ?></td>
                          <td><?php echo $kullanicicek['kullanici_tel'] ?></td>
                          <td><?php echo $kullanicicek['kullanici_mail'] ?></td>
                          <td><?php echo $kullanicicek['kullanici_adres'] ?></td>
                          <td><?php if ($kullanicicek['kullanici_durum']==1) { ?>
                          <center><button class="btn btn-danger btn-xs">Aktif</button></center>
                        <?php  }elseif($kullanicicek['kullanici_durum']==2){?><center><button class="btn btn-success btn-xs">Pasif</button></center><?php } ?></td>
                          
                        </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>