
<?php include "header.php";
//Belirli veriyi seçme işlemi
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
$sepetsor=$db->prepare("SELECT * FROM sepet where kullanici_id=:kullanici_id order by urun_id DESC");
$sepetsor->execute(array('kullanici_id'=>$kullanici_id));
$urunsor=$db->prepare("SELECT * FROM stokurunler order by urun_id DESC");
$urunsor->execute();
?>
    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Sepet</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sepet<small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      
                      <center><a href="index.php"><button class="btn btn-danger btn-sm">Alışverişe Devam</button></a></center>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                   <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                      Hızlıca sepeti düzenleyebilirsiniz.
                    </p>
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Barkod No</th>
                          <th>Ürün Adı</th>
                          <th>Satış Fiyatı</th>
                          <th>Birim</th>
                          <th>Miktar</th>
                          <th>Satır Toplam</th>
                          <th>Güncelle</th>
                          <th>Sil</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                while($sepetcek=$sepetsor->fetch(PDO::FETCH_ASSOC)) {
                $urun_id=$sepetcek['urun_id'];
                $urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:urun_id");
                $urunsor->execute(array(
                   'urun_id' => $urun_id
                ));

          $uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);

                 ?>
                        <tr>
                          <td><?php echo $uruncek['urun_barkod'] ?></td>
                          <td><?php echo $uruncek['urun_ad'] ?></td>
                          <td><?php echo $uruncek['urun_satis'] ?>₺</td>
                          <td><?php echo $uruncek['urun_birim'] ?></td>
                          <td><form action="../netting/islem.php" method="POST">
                                    <input type="hidden" name="urun_id" value="<?php echo $sepetcek['urun_id'] ?>">
                                    <input id="middle-name" name="urun_adet" class="form-control" type="number" value="<?php echo $sepetcek['urun_adet'] ?>"  style="width: 100px"></td>
                                    <input type="hidden" name="kullanici_id" value="<?php echo $kullanici_id?>">
                          <td><?php echo $satir=$sepetcek['urun_adet']*$uruncek['urun_satis']?> ₺</td>
                                    <td><button type="submit" name="sepetguncelle" class="btn btn-primary">Güncelle</button></form></td>
                          <td><center><a href="../netting/islem.php?urun_id=<?php echo $uruncek['urun_id']; ?>&surunsil=ok"><button class="btn btn-danger btn-xs">Sil</button></a></center></td>
                        </tr> 
                        <?php $sepet_id=$sepetcek['sepet_id']; $geneltoplam=$geneltoplam+$satir; }?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>
            </div>
          </div>
          <div style="text-align: right; padding-right: 100px; font-size: 25px;"><a href="../netting/islem.php?sepet_id=<?php echo $sepet_id ?>&kullanici_id=<?php echo $kullanici_id ?>&sepetsil=ok"><button class="btn btn-danger btn-xs">Sepeti Temizle</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="siparisolustur.php?sepet_id=<?php echo $sepet_id ?>&geneltoplam=<?php echo $geneltoplam ?>&siparis=ok"><button class="btn btn-primary btn-xs">Alışverişi Tamamla</button></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Genel Toplam :<?php echo $geneltoplam?> ₺</b></div>
        </div>
        <!-- /page content -->
<?php include "footer.php" ?>