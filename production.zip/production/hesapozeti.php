
<?php include "header.php";

$carisor=$db->prepare("SELECT * FROM cariler where cari_id=:id");
$carisor->execute(array(
  'id' => $_GET['cari_id']
  ));

$caricek=$carisor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Cari Hesap Özeti</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Cari Hesap Özeti <small> </small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <center><a href="odemeislemleri.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-danger btn-sm">Ödeme Yap</button></a></center>
                      <center><a href="odemeler.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-danger btn-sm">Ödeme Özeti</button></a></center>
                      <center><a href="cariguncelle.php?cari_id=<?php echo $caricek['cari_id']; ?>"><button class="btn btn-danger btn-sm">Bilgileri Güncelle</button></a></center>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Cari Tipi</th>
                          <th>Ad Soyad / Firma Ünvanı</th>
                          <th>Telefon</th>
                          <th>Email</th>
                          <th>Adres</th>
                          <th>Bakiye</th>
                          <th>Tarih(Şimdi)</th>
                        </tr>
                      </thead>


                      <tbody>
                        <tr>
                          <td><?php if ($caricek['cari_tip']==1) {
                            echo"Müşteri";
                          }else{
                            echo "Toptancı";
                          } ?></td>
                          <td><?php echo $caricek['cari_adsoyad'] ?></td>
                          <td><?php echo $caricek['cari_telefon'] ?></td>
                          <td><?php echo $caricek['cari_email'] ?></td>
                          <td><?php echo $caricek['cari_adres'] ?></td>
                          <td><?php echo $caricek['cari_bakiye'] ?> ₺</td>
                          <td><?php date_default_timezone_set('Europe/Istanbul');
                              echo date('d.m.Y H:i:s');
                           ?></td>
                        </tr>
                      </tbody>
                       <thead>
                         
                        <tr>
                          <th>Sipariş No</th>
                          <th>Ürün Adı</th>
                          <th>Miktar</th>
                          <th>Birim Fiyat</th>
                          <th colspan="2">Satır Toplam</th>
                          <th>Alınan Tarih</th>
                        </tr>
                      </thead>


                      <tbody>
                        <?php
                          $siparissor=$db->prepare("SELECT * FROM siparisler where cari_id=:id");
                          $siparissor->execute(array(
                          'id' => $_GET['cari_id']
                           ));
                         while($sipariscek=$siparissor->fetch(PDO::FETCH_ASSOC)) { 
                          $urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:id");
                          $urunsor->execute(array(
                          'id' => $sipariscek['urun_id']
                           ));

                          $uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
                           
                          ?>
                         
                        <tr>
                          <td><?php echo $sipariscek['siparis_no'] ?></td>
                          <td><?php echo $uruncek['urun_ad'] ?></td>
                          <td><?php echo $sipariscek['urun_adet'] ?></td>
                          <td><?php echo $sipariscek['urun_satis'] ?></td>
                          <td colspan="2"><?php echo $satirtop=$sipariscek['urun_adet']*$sipariscek['urun_satis'] ?> ₺</td>
                          <td><?php echo date_format(date_create($sipariscek['siparis_tarih']), 'd-m-Y / H:i:s'); ?></td>
                        </tr>
                      <?php $genel+=$satirtop; } ?>
                      <tr>
                        <td colspan="7" align="right"><b>Cari Toplam Sipariş Tutarı : <?php echo $genel ?> ₺</b></td>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>