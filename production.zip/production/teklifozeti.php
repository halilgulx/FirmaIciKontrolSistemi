
<?php include "header.php";
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}

$teklifbsor=$db->prepare("SELECT * FROM teklifbilgi where teklif_id=:id and kullanici_id=:kullanici_id");
$teklifbsor->execute(array(
  'id' => $_GET['teklif_id'],
  'kullanici_id' => $kullanici_id
  ));

$teklifbcek=$teklifbsor->fetch(PDO::FETCH_ASSOC);

$carisor=$db->prepare("SELECT * FROM cariler where cari_id=:id and kullanici_id=:kullanici_id");
$carisor->execute(array(
  'id' => $teklifbcek['cari_id'],
  'kullanici_id' => $kullanici_id
  ));

$caricek=$carisor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Teklif İçeriği</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Teklif İçeriği <small> </small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link" href="teklifler.php"><b class="fa fa-chevron-left" style="color: grey;"></b></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                         
                        <tr>
                          <th>Cari Tipi</th>
                          <th>Ad Soyad / Firma Ünvanı</th>
                          <th>Telefon</th>
                          <th>Email</th>
                          <th>Açıklama</th>
                          <th>Teklif Tutarı</th>
                          <th>Teklif Tarihi</th>
                        </tr>
                      </thead>


                      <tbody>
                        <tr>
                          <td><?php echo $caricek['cari_adsoyad'] ?></td>
                          <td><?php echo $caricek['cari_telefon'] ?></td>
                          <td><?php echo $caricek['cari_email'] ?></td>
                          <td><?php echo $caricek['cari_adres'] ?></td>
                          <td><?php echo $teklifbcek['cari_aciklama'] ?></td>
                          <td><?php echo $teklifbcek['teklif_tutar'] ?> ₺</td>
                          <td><?php echo $teklifbcek['teklif_tarih'] ?></td>
                        </tr>
                      </tbody>
                       <thead>
                         
                        <tr>
                          <th>Sipariş No</th>
                          <th>Ürün Adı</th>
                          <th>Miktar</th>
                          <th>Birim Fiyat</th>
                          <th colspan="2">Satır Toplam</th>
                          <th>Alınan Tarih</th>
                        </tr>
                      </thead>


                      <tbody>
                        <?php
                          $teklifsor=$db->prepare("SELECT * FROM teklifler where teklif_id=:id");
                          $teklifsor->execute(array(
                          'id' => $_GET['teklif_id']
                           ));
                         while($teklifcek=$teklifsor->fetch(PDO::FETCH_ASSOC)) { 
                          $urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:id");
                          $urunsor->execute(array(
                          'id' => $teklifcek['urun_id']
                           ));

                          $uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
                           
                          ?>
                         
                        <tr>
                          <td><?php echo $teklifcek['teklif_id'] ?></td>
                          <td><?php echo $uruncek['urun_ad'] ?></td>
                          <td><?php echo $teklifcek['urun_adet'] ?></td>
                          <td><?php echo $teklifcek['urun_satis'] ?></td>
                          <td colspan="2"><?php echo $satirtop=$teklifcek['urun_adet']*$teklifcek['urun_satis'] ?> ₺</td>
                          <td><?php echo $teklifcek['teklif_tarih'] ?></td>
                        </tr>
                      <?php $genel+=$satirtop; } ?>
                      <tr>
                        <td colspan="7" align="right"><b>Toplam Teklif Tutarı : <?php echo $genel ?> ₺</b></td>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>