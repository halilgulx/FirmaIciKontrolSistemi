
<?php include "header.php";
	if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}

$urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:id");
$urunsor->execute(array(
  'id' => $_GET['urun_id']
  ));

$uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);
 ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ürünü İncele</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ürünü İncele</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link" href="urunstok.php" title="Ürünler Sayfasına Dön"><i class="fa fa-chevron-left" style="color: grey;"></i></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content"><br />
									<form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">

										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Barkod No <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input type="text" id="first-name" name="urun_barkod" value="<?php echo $uruncek['urun_barkod'] ?>" required="required" class="form-control " disabled>
												<span class="fa fa-barcode form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Stok Kodu <span class="required">*</span>
											</label>
											<div class="col-md-6 col-sm-6 ">
												<input type="text" id="last-name" name="urun_stokkod" value="<?php echo $uruncek['urun_stokkod'] ?>" required="required" disabled class="form-control">
												<span class="fa fa-cubes form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Ürün Adı</label>
											<div class="col-md-6 col-sm-6 ">
												<input id="middle-name" class="form-control" value="<?php echo $uruncek['urun_ad'] ?>" type="text" name="urun_ad" disabled>
												<span class="fa fa-pencil form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Ürün Grubu</label>
											<div class="col-md-6 col-sm-6 ">
												<select id="heard" name="urun_grup" class="form-control" required disabled="">
													<option value="<?php echo $uruncek['urun_grup'] ?>"><?php echo $uruncek['urun_grup'] ?></option>
													<option value="Hırdavat">Hırdavat</option>
													<option value="Boya">Boya</option>
													<option value="Elektrik">Elektrik</option>
													<option value="Tesisat">Tesisat</option>
												</select>
												<span class="fa fa-cubes form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Ürün Birim</label>
											<div class="col-md-6 col-sm-6 ">
												<select id="heard" name="urun_birim" class="form-control" required disabled="">
													<option value="<?php echo $uruncek['urun_birim'] ?>"><?php echo $uruncek['urun_birim'] ?></option>
													<option value="Adet">Adet</option>
													<option value="Litre">Litre</option>
													<option value="Kilogram">Kilogram</option>
													<option value="Metre">Metre</option>
												</select>
												<span class="fa fa-cubes form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Alış Fiyatı</label>
											<div class="col-md-6 col-sm-6 ">
												<input id="middle-name" class="form-control" type="text" value="<?php echo $uruncek['urun_alis'] ?>" name="urun_alis" disabled>
												<span class="fa fa-try form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Satış Fiyatı</label>
											<div class="col-md-6 col-sm-6 ">
												<input id="middle-name" value="<?php echo $uruncek['urun_satis'] ?>" class="form-control" type="text" name="urun_satis" disabled="">
												<span class="fa fa-try form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Stok Adeti</label>
											<div class="col-md-6 col-sm-6 ">
												<input id="middle-name" class="form-control"  value="<?php echo $uruncek['urun_stok'] ?>" type="text" name="urun_stok" disabled="" >
												<span class="fa fa-cubes form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">KDV Oranı</label>
											<div class="col-md-6 col-sm-6 ">
												<select id="heard" class="form-control" name="urun_kdv" disabled="" required>
													<option value="<?php echo $uruncek['urun_kdv'] ?>"><?php echo $uruncek['urun_kdv'] ?></option>
														<option value="6">6</option>
													<option value="8">8</option>
													<option value="18">18</option>
												</select>
												<span class="fa fa-link form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										<div class="item form-group">
											<label for="middle-name" class="col-form-label col-md-3 col-sm-3 label-align">Açıklama</label>
											<div class="col-md-6 col-sm-6 ">
											<textarea  class="resizable_textarea form-control" name="urun_aciklama" disabled=""><?php echo $uruncek['urun_aciklama'] ?></textarea>
											<span class="fa fa-edit form-control-feedback right" aria-hidden="true"></span>
											</div>
										</div>
										
										<div class="item form-group">
											<div class="col-md-6 col-sm-6 offset-md-3">
												<input type="hidden" name="urun_id" value="<?php echo $uruncek['urun_id'] ?>"> 
												
											</div>
										</div>
										<div class="ln_solid"></div>
									</form>
									<a href="index.php"><button class="btn btn-primary">Hızlı İşlemlere Git</button></a>
									<a href="urunstok.php"><button class="btn btn-primary">Stok Ürünlere Git</button></a>
									<a href="qrkodolustur.php?urun_id=<?php echo $uruncek['urun_id'] ?>"><button class="btn btn-primary">Qr Kodu Oluştur</button></a>
									<form action="../netting/islem.php" method="POST">
                                    <input type="hidden" name="urun_id" value="<?php echo $uruncek['urun_id'] ?>">
                                    <input type="hidden" name="kullanici_id" value="<?php echo $kullanici_id ?>">
                                    <input id="middle-name" class="form-control" type="hidden" value ="1"name="urun_adet"">
                           					<button type="submit" name="sepeteekle" class="btn btn-danger">Sepete Ekle</button></form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>