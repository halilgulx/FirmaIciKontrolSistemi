
<?php include "header.php" ?>
 <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Yeni Çalışan Oluştur</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Yeni Çalışan<small> <?php 

              if ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php } elseif ($_GET['durum']=="eksiksifre") {?>

              <b style="color:red;">Şifre en az 8 haneli olmalı...</b>

			        <?php } elseif ($_GET['durum']=="sifreleruyusmuyor") {?>

              <b style="color:red;">Şifreler uyuşmuyor...</b>

              <?php } elseif ($_GET['durum']=="emailalindi") {?>

              <b style="color:red;">Mail adresi kayıtlı...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link" href="calisanlar.php" title="Carilere dön"><i class="fa fa-chevron-left" style="color: grey;"></i></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                                  <!-- start form for validation -->
                <form id="demo-form2" action="../netting/islem.php" method="POST" data-parsley-validate class="form-horizontal form-label-left">
                   
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Ad Soyad<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" name="kullanici_ad" class="form-control "><span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Kullanıcı Adı<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="text" id="first-name" required="required" name="kullanici_kadi" class="form-control "><span class="fa fa-user form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Telefon <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="phone" id="first-name" name="kullanici_tel" required="required" class="form-control ">
                        <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Email <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="email" id="first-name" required="required" name="kullanici_mail" class="form-control "><span class="fa fa-envelope form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Şifre <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="password" id="first-name" required="required" name="kullanici_passwordone" class="form-control "><span class="fa fa-key form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                     <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Şifre Tekrar<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="password" id="first-name" required="required" name="kullanici_passwordtwo" class="form-control "><span class="fa fa-key form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="first-name">Güvenlik Kelimeniz <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                        <input type="phone" id="first-name" name="kullanici_guvenlik" required="required" class="form-control ">
                        <span class="fa fa-key form-control-feedback right" aria-hidden="true"></span>
                      </div>
                    </div>
                    <div class="item form-group">
                      <label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Adres <span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 ">
                       <textarea class="resizable_textarea form-control" name="kullanici_adres" placeholder="Adresinizi Giriniz..."></textarea>
                        <span class="fa fa-home form-control-feedback right"aria-hidden="true"></span>
                      </div>
                    </div>
                   
                    <div class="ln_solid"></div>
                    <div class="item form-group">
                      <div class="col-md-6 col-sm-6 offset-md-3">
                        <input type="hidden" id="first-name" name="kullanici_durum" value="1" required="required" class="form-control ">
                        <input type="hidden" id="first-name" name="kullanici_yetki" value="1" required="required" class="form-control ">
                        <input type="hidden" name="kullanici_yonetici" value="<?php echo $kullanicicek['kullanici_id'] ?>">
                        <input type="hidden" name="kullanici_odeme" value="<?php echo $kullanicicek['kullanici_odeme'] ?>">
                        <button class="btn btn-danger" type="reset">Temizle</button>
                        <button type="submit" name="calisanolustur" class="btn btn-primary">Çalışan Oluştur</button>
                      </div>
                    </div>

                  </form>
                  <!-- end form for validations -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

<?php include "footer.php" ?>