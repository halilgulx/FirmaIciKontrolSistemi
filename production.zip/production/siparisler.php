
<?php include "header.php";
//Belirli veriyi seçme işlemi
if ($kullanicicek['kullanici_yonetici']==0) {
  $kullanici_id=$kullanicicek['kullanici_id'];
}else{
  $kullanici_id=$kullanicicek['kullanici_yonetici'];
}
$siparissor=$db->prepare("SELECT * FROM siparisler where kullanici_id=:kullanici_id order by urun_id DESC");
$siparissor->execute(array('kullanici_id'=>$kullanici_id));
$urunsor=$db->prepare("SELECT * FROM stokurunler where kullanici_id=:kullanici_id order by urun_id DESC");
$urunsor->execute(array('kullanici_id'=>$kullanici_id));
?>
    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Siparişler</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Ara...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search"></i></button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Siparişler<small> <?php 

              if ($_GET['durum']=="ok") {?>

              <b style="color:green;">İşlem Başarılı...</b>

              <?php } elseif ($_GET['durum']=="no") {?>

              <b style="color:red;">İşlem Başarısız...</b>

              <?php }

              ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                   <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <p class="text-muted font-13 m-b-30">
                      Siparişlerin tümünü görebilirsiniz.
                    </p>
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Sipariş No</th>
                          <th>Ürün Adı</th>
                          <th>Satış Fiyatı</th>
                          <th>Birim</th>
                          <th>Miktar</th>
                          <th>Satır Toplam</th>
                          <th>Alınan Tarih</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                while($sipariscek=$siparissor->fetch(PDO::FETCH_ASSOC)) {
                $urun_id=$sipariscek['urun_id'];
                $urunsor=$db->prepare("SELECT * FROM stokurunler where urun_id=:urun_id and kullanici_id=:kullanici_id");
                $urunsor->execute(array(
                   'urun_id' => $urun_id,
                   'kullanici_id' => $kullanici_id
                ));

          $uruncek=$urunsor->fetch(PDO::FETCH_ASSOC);

                 ?>
                        <tr>
                          <td><?php echo $sipariscek['siparis_no'] ?></td>
                          <td><?php echo $uruncek['urun_ad'] ?></td>
                          <td><?php echo $uruncek['urun_satis'] ?>₺</td>
                          <td><?php echo $uruncek['urun_birim'] ?></td>
                          <td><form action="../netting/islem.php" method="POST">
                                    <input type="hidden" name="urun_id" value="<?php echo $sepetcek['urun_id'] ?>">
                                    <input id="middle-name" name="urun_adet" disabled="disabled" class="form-control" type="number" value="<?php echo $sipariscek['urun_adet'] ?>"  style="width: 100px"></td>

                          <td><?php echo $satir=$sipariscek['urun_adet']*$uruncek['urun_satis']?> ₺</td>
                                    <td><?php echo $sipariscek['siparis_tarih']?></td>
                          
                        </tr> 
                        <?php $siparis_id=$sipariscek['siparis_id']; $geneltoplam=$geneltoplam+$satir; }?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>
            </div>
          </div>
          <div style="text-align: right; padding-right: 100px; font-size: 25px;"><b>Genel Toplam :<?php echo $geneltoplam?> ₺</b></div>
        </div>
        <!-- /page content -->
<?php include "footer.php" ?>